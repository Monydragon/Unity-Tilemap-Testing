#+============================================================================+#
# Script: Window_TextBox
# Version: 1.0.0
# Last Update: September 12th, 2013
# Author: Zalerinian (~ZF)
#==============================================================================#
# Version History
#  July 21st, 2013
#   - Initial release.
#
#  September 12th, 2013
#   - You can now change how long the window waits before it will re-paste what
#     is currently copied.
#   - Fixed a bug that was caused when using caps lock and pressing a number.
#==============================================================================#
# Description
#  Window_TextBox is a plug-n-play script that allows you to create a textbox
#  that can be typed into in real time.
#==============================================================================#
# Support
#  For support, bug reports, or feedback, please email scripts@razelon.tk,
#  or send me (Zalerinian) a private message (PM) on the RPG maker forums.
#==============================================================================#
# Credit
#  I do not require credit to be given. You may use this script in a
#  commercial or non-commercial game, so long as you do not claim that
#  you wrote it.
#==============================================================================#
# Features
#  - Realtime input via the keyboard
#  - Supports Unicode characters!
#  - Supports copy and paste!
#  - The window scrolls to always fit the text!
#  - A cursor to show where you are currently editing!
#  - Support for the Home, End, Delete keys!
#  - Ability to save text to a game variable!
#  - No need to create a scene, create a window right on the map!
#==============================================================================#
# Method List
# + = new method; * = aliased method
#  + Clipboard module
#   + GetText
#   + SetText
#
#
#  + Window_TextBox
#   + deactivate
#   + dispose
#   + activate
#   + get_keys
#   + get_input
#   + initialize
#   + process_key
#   + remove_newline
#   + resize_text
#   + update
#   + update_cursor
#   + update_scroll
#   + update_window
#   + shutdown
#   + wait
#
#  Scene_Map
#  * call_menu
#==============================================================================#
# Usage
#  Using a textbox depends on how you want to use it. You can use it in events,
#  or in fully scripted scenes. In either case, you must make a textbox by
#  calling Window_TextBox.new
#
# - Getting Input in Scenes (This requires script edits!!)- 
#  Simply activate the window and it will run itself, grabbing all input from
#  the keyboard. This will not stop a scene scripted close from press the
#  cancel button (default the escape key). Once you are done having the user
#  type into the textbox, use the 'text' method to get what the player typed
#  in.
#
# - Getting Input in Events -
#  To get input from events, you need to call the window's get_input method.
#  This will run until the player presses the enter key (and the textbox isn't
#  blank), or until the press the escape key. If the escape key is pressed, the
#  text is set to numerical -1 (not a string holding -1, the actual number).
# 
#  You have two options when getting text from an event. You may simply set
#  a variable equal to the text by doing 'text = window.get_input', or you
#  may set one of the game variables to what the user types in. To have the
#  text set to a game variable, specify the ID when you call the get_input
#  method.
#==============================================================================#
# Examples
# - Set the text to variable 15 -
#  my_window = Window_TextBox.new
#  my_window.get_input(15)
#
#
# - Getting the text directly -
#  my_window = Window_TextBox.new
#  my_text = my_window.get_input
#  *do things with my_text*
#==============================================================================#

$imported = {} if $imported.nil?
$imported["ZF Window_TextBox"] = 1.10

module Clipboard
  # Clipboard functions
  OpenClipboard = Win32API.new('user32', 'OpenClipboard', ['I'], 'I');
  CloseClipboard = Win32API.new('user32', 'CloseClipboard', [], 'I');
  EmptyClipboard = Win32API.new('user32', 'EmptyClipboard', [], 'I');
  GetClipboardData = Win32API.new('user32', 'GetClipboardData', ['I'], 'I');
  SetClipboardData = Win32API.new('user32', 'SetClipboardData', ['I', 'I'], 'I');
  Alloc = Win32API.new('kernel32', 'GlobalAlloc', ['I','I'], 'I');
  Lock = Win32API.new('kernel32', 'GlobalLock', ['I'], 'P');
  Unlock = Win32API.new('kernel32', 'GlobalUnlock', ['I'], 'I');
  Len = Win32API.new('kernel32', 'lstrlenA', ['P'], 'I');
  Copy = Win32API.new('kernel32', 'lstrcpyA', ['I', 'P'], 'P');
  LockI = Win32API.new('kernel32', 'GlobalLock', ['I'], 'I');
  
  
  #--------------------------------------------------------------------------
  # Clipboard: GetText                                             NEW METHOD
  #  * This method will get the text currently on the users clipboard and
  #  * return it.
  #--------------------------------------------------------------------------
  def self.GetText
    result = ""
    if OpenClipboard.Call(0) != 0
      if (h = GetClipboardData.Call(1)) != 0
        if (p = Lock.Call(h)) != 0
          result = p;
          Unlock.Call(h);
        end
      end
      CloseClipboard.Call;
    end
    return result;
  end
  
  #--------------------------------------------------------------------------
  # Clipboard: SetText                                             NEW METHOD
  #  * This will allow you to set the text of the clipboard so that the user
  #  * may paste information elsewhere.
  #--------------------------------------------------------------------------  
  def self.SetText(text)
    if (text == nil) || (text == "")
      return
    end
    if OpenClipboard.Call(0) != 0
      EmptyClipboard.Call();
      len = Len.Call(text);
      hmem = Alloc.Call(0x2000, len+1);
      pmem = LockI.Call(hmem);
      Copy.Call(pmem, text);
      SetClipboardData.Call(1, hmem);
      Unlock.Call(hmem);
      CloseClipboard.Call;
    end
  end
end

module ZKey
  KEY   = Win32API.new("user32.dll", "GetKeyState",      ["i"], "i")
  AKEY  = Win32API.new("user32.dll", "GetAsyncKeyState", ["i"], "i")
  
  # A hash to contain the virtual codes Windows assigns each key
  Keys = {
#   backspace    tab         enter         any shift     any control     any alt     caps lock    escape      spacebar
    _back: 0x08, _tab: 0x09, _enter: 0x0D, _shift: 0x10, _control: 0x11, _alt: 0x12, _capl: 0x14, _esc: 0x1B, _space: 0x20,
#   page up      page down    end         home         left arrow   up arrow   right arrow   down arrow   print screen key
    _pgup: 0x21, _pgdn: 0x22, _end: 0x23, _home: 0x24, _left: 0x25, _up: 0x26, _right: 0x27, _down: 0x28, _print_screen: 0x2C,
#   insert         delete         help         0         1         2         3         4         5         6         7
    _insert: 0x2D, _delete: 0x2E, _help: 0x2F, _0: 0x30, _1: 0x31, _2: 0x32, _3: 0x33, _4: 0x34, _5: 0x35, _6: 0x36, _7: 0x37,
#   8          9         A         B         C         D         E         F         G         H         I         J
     _8: 0x38, _9: 0x39, _a: 0x41, _b: 0x42, _c: 0x43, _d: 0x44, _e: 0x45, _f: 0x46, _g: 0x47, _h: 0x48, _i: 0x49, _j: 0x4A,
#   K         L         M         N         O         P         Q         R         S         T         U         V
    _k: 0x4B, _l: 0x4C, _m: 0x4D, _n: 0x4E, _o: 0x4F, _p: 0x50, _q: 0x51, _r: 0x52, _s: 0x53, _t: 0x54, _u: 0x55, _v: 0x56, 
#   W         X         Y         Z         left win     right win    numpad 0    numpad 1      numpad 2     numpad 3
    _w: 0x57, _x: 0x58, _y: 0x59, _z: 0x5A, _lwin: 0x5B, _rwin: 0x5C, _num0: 0x60, _num1: 0x61, _num2: 0x62, _num3: 0x63,
#   numpad 4     numpad 5     numpad 6     numpad 7     numpad 8     numpad 9     numpad *      numpad +    numpad -
    _num4: 0x64, _num5: 0x65, _num6: 0x66, _num7: 0x67, _num8: 0x68, _num9: 0x69, _multi: 0x6A, _add: 0x6B, _sub: 0x6D, 
#   numpad .    numpad /    FN 1       FN 2       FN 3       FN 4       FN 5       FN 6       FN 7       FN 8
    _dec: 0x6E, _div: 0x6F, _f1: 0x70, _f2: 0x71, _f3: 0x72, _f4: 0x73, _f5: 0x74, _f6: 0x75, _f7: 0x76, _f8: 0x77,
#   FN 9       FN 10       FN 11       FN 12       FN 13       FN 14       FN 15       FN 16       FN 17       FN 18
    _f9: 0x78, _f10: 0x79, _f11: 0x7A, _f12: 0x7B, _f13: 0x7C, _f14: 0x7D, _f15: 0x7E, _f16: 0x7F, _f17: 0x80, _f18: 0x81,
#   FN 19       FN 20       FN 21       FN 22       FN 23       FN 24       left shift     right shift    left ctrl
    _f19: 0x82, _f20: 0x83, _f21: 0x84, _f22: 0x85, _f23: 0x86, _f24: 0x87, _lshift: 0xA0, _rshift: 0xA1, _lcontrol: 0xA2, 
#   right xtrl       left alt     right alt    :             =              ,             -             .
    _rcontrol: 0xA3, _lalt: 0xA4, _ralt: 0xA5, _colon: 0xBA, _equals: 0xBB, _comma: 0xBC, _minus: 0xBD, _period: 0xBE,
#
    _slash: 0xBF, _tilde: 0xC0, _lbrace: 0xDB, _backslash: 0xDC, _rbrace: 0xDD, _quote: 0xDE
  }
  
  # A hash to contain all the code-to-character conversions.
  Characters = {
    Keys[:_back] => "$$BACK", Keys[:_tab] => "$$TAB", Keys[:_enter] => "$$ENTER", Keys[:_shift] => "$$SHIFT", 
    Keys[:_control] => "$$CTRL", Keys[:_alt] => "$$ALT", Keys[:_capl] => "$$CAPSL", Keys[:_esc] => "$$ESCAPE",
    Keys[:_space] => " ", Keys[:_pgup] => "$$PGUP", Keys[:_pgdn] => "$$PGDN", Keys[:_end] => "$$END",
    Keys[:_home] => "$$HOME", Keys[:_left] => "$$LEFT", Keys[:_up] => "$$UP", Keys[:_right] => "$$RIGHT",
    Keys[:_down] => "$$DOWN", Keys[:_print_screen] => "$$PRNTSCN", Keys[:_insert] => "$$INS", 
    Keys[:_delete] => "$$DELETE", Keys[:_help] => "$$HELP", Keys[:_0] => "0", Keys[:_1] => "1",
    Keys[:_2] => "2", Keys[:_3] => "3", Keys[:_4] => "4", Keys[:_5] => "5", Keys[:_6] => "6",
    Keys[:_7] => "7", Keys[:_8] => "8", Keys[:_9] => "9", Keys[:_a] => "a", Keys[:_b] => "b",
    Keys[:_c] => "c", Keys[:_d] => "d", Keys[:_e] => "e", Keys[:_f] => "f", Keys[:_g] => "g",
    Keys[:_h] => "h", Keys[:_i] => "i", Keys[:_j] => "j", Keys[:_k] => "k", Keys[:_l] => "l",
    Keys[:_m] => "m", Keys[:_n] => "n", Keys[:_o] => "o", Keys[:_p] => "p", Keys[:_q] => "q",
    Keys[:_r] => "r", Keys[:_s] => "s", Keys[:_t] => "t", Keys[:_u] => "u", Keys[:_v] => "v",
    Keys[:_w] => "w", Keys[:_x] => "x", Keys[:_y] => "y", Keys[:_z] => "z", Keys[:_lwin] => "$$LWIN",
    Keys[:_rwin] => "$$RWIN", Keys[:_num0] => "0", Keys[:_num1] => "1", Keys[:_num2] => "2",
    Keys[:_num3] => "3", Keys[:_num4] => "4", Keys[:_num5] => "5", Keys[:_num6] => "6",
    Keys[:_num7] => "7", Keys[:_num8] => "8", Keys[:_num9] => "9", Keys[:_multi] => "*",
    Keys[:_add] => "+", Keys[:_sub] => "-", Keys[:_dec] => ".", Keys[:_div] => ".", Keys[:_f1] => "$$F1",
    Keys[:_f2] => "$$F2", Keys[:_f3] => "$$F3", Keys[:_f4] => "$$F4", Keys[:_f5] => "$$F5",
    Keys[:_f6] => "$$F6", Keys[:_f7] => "$$F7", Keys[:_f8] => "$$F8", Keys[:_f9] => "$$F9",
    Keys[:_f10] => "$$F10", Keys[:_f11] => "$$F11", Keys[:_f12] => "$$F12", Keys[:_f13] => "$$F13",
    Keys[:_f14] => "$$F14", Keys[:_f15] => "$$F15", Keys[:_f16] => "$$F16", Keys[:_f17] => "$$F17",
    Keys[:_f18] => "$$F18", Keys[:_f19] => "$$F19", Keys[:_f20] => "$$F20", Keys[:_f21] => "$$F21",
    Keys[:_f22] => "$$F22", Keys[:_f23] => "$$F23", Keys[:_f24] => "$$F24", Keys[:_lshift] => "$$LSHIFT",
    Keys[:_rshift] => "$$RSHIFT", Keys[:_lcontrol] => "$$LCTRL", Keys[:_rcontrol] => "$$RCTRL", 
    Keys[:_lalt] => "$$LALT", Keys[:_ralt] => "$$RALT", Keys[:_colon] => ":", Keys[:_equals] => "=",
    Keys[:_comma] => ",", Keys[:_minus] => "-", Keys[:_period] => ".", Keys[:_slash] => "/",
    Keys[:_tilde] => "`", Keys[:_lbrace] => "[", Keys[:_backslash] => "\\", Keys[:_rbrace] => "]", 
    Keys[:_quote] => "\'",
  }
  
  # A hash to contain special characters
  Special_Characters = {
    "`" => "~", "1" => "!", "2" => "@", "3" => "#", "4" => "$", "5" => "%", "6" => "^", "7" => "&", "8" => "*",
    "9" => "(", "0" => ")", "-" => "_", "=" => "+", "[" => "{", "]" => "}", "\\" => "|", ";" => ":", "\'" => "\"",
    "," => "<", "." => ">", "/" => "?",
    
  }
  
  # An array containing system keys that should ignore the pause when holding a key
  Fast_Keys = [
    Keys[:_shift], Keys[:_control], Keys[:_alt], Keys[:_lshift],
    Keys[:_rshift], Keys[:_lalt], Keys[:_ralt], Keys[:_lcontrol], Keys[:_rcontrol]
  ]
  
  @released = Hash.new{|h, k| h[k] = false }
  @triggers = Hash.new{|h, k| h[k] = false }
  @pressed  = Hash.new{|h, k| h[k] = false }
  
  #--------------------------------------------------------------------------
  # ZKey: update                                                   NEW METHOD
  # * Update will update input to see if a key was triggered (just pressed),
  # * pressed and is being held now, or if the key was just released.
  #--------------------------------------------------------------------------
  def self.update
    Keys.each_value{ |key|
      (@pressed[key] == false && AKEY.call(key) != 0) ? @triggers[key] = true : @triggers[key] = false
      AKEY.call(key) != 0 ? @pressed[key] = true : @pressed[key] = false
      (@pressed[key] == true && AKEY.call(key) == 0) ? @released[key] = true : @released[key] = false
    }
  end
  
  #--------------------------------------------------------------------------
  # ZKey: press?                                                   NEW METHOD
  #  * The key is currently pressed (Similar to Input.repeat?)
  #--------------------------------------------------------------------------
  def self.press?(key)
    @pressed[Keys[key]]
  end
  
  #--------------------------------------------------------------------------
  # ZKey: trigger?                                                 NEW METHOD
  #  * The key was pressed once?
  #--------------------------------------------------------------------------
  def self.trigger?(key)
    @triggers[Keys[key]]
  end
  
  #--------------------------------------------------------------------------
  # Zkey: toggle?                                                  NEW METHOD
  #  * The key is toggled (Caps lock, for example)
  #--------------------------------------------------------------------------
  def self.toggle?(key)
    key = Keys[key]
    key ? nil : (return false)
    if KEY.call(key) == 1
      return true
    else
      return false
    end
  end
  
  #--------------------------------------------------------------------------
  # Zkey: any_key?                                                 NEW METHOD
  #  * Any key is pressed?
  #--------------------------------------------------------------------------
  def self.any_key?
    @pressed.any?{|i| i[1] == true}
  end  
end

module Input
  class << self
    alias zale_zkey_update_chg74hftei update
  end
  
  #--------------------------------------------------------------------------
  # Input: update                                              ALIASED METHOD
  # * Input's update was aliased to update the ZKey module for extended key
  # * support.
  #--------------------------------------------------------------------------
  def self.update
    ZKey.update
    zale_zkey_update_chg74hftei
  end
  
end

class Window_TextBox < Window_Base
  attr_accessor :text, :cursor
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Deactivate                                     NEW METHOD
  #  * Calling this method will stop the window from getting input and hide
  #  * the cursor from view.
  #--------------------------------------------------------------------------
  def deactivate
    @cursor_sprite.visible = false
    super
    self
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Dispose                                        NEW METHOD
  #  * Dispose deletes the window and it's components from memory, taking
  #  * them off the screen.
  #--------------------------------------------------------------------------
  def dispose
    super
    @cursor_bitmap.dispose
    @cursor_sprite.dispose
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Activate                                       NEW METHOD
  #  * Activate will allow the window to grab input, as well as show the
  #  * cursor on the screen.
  #--------------------------------------------------------------------------
  def activate
    @cursor_sprite.visible = true
    super
    self
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Get_keys                                       NEW METHOD
  #  * Get_Keys loops through the list of assigned keys and checks if any
  #  * have been pressed. If they have, it will send them to process_key.
  #--------------------------------------------------------------------------
  def get_keys
      keys = ZKey::Keys.keys
      @keys["clipboard"] > 0 ? @keys["clipboard"] -= 1 : nil
      keys.each { |button|
        key = ZKey::Keys[button]
        !ZKey.press?(ZKey::Keys.index(key)) && @keys[key] != -2 ? @keys[key] = 0 : nil
        if ZKey.press?(button)
          shift = ZKey.press?(:_shift)
          caps  = ZKey.toggle?(:_capl)
          if [-2, -1, 0].include?(@keys[key])
            process_key(ZKey::Characters[key], key, (shift && !caps || !shift && caps), (shift) ) # Character, Syskey(the number), Upper, Upper special.
          else
            @keys[key] == 1 ? @keys[key] = -1 : @keys[key] -= 1
          end
        end
      }
      @fiber = nil
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Initialize                                     NEW METHOD
  #  * Initialize creates and sets up the window for use. If any of the
  #  * parameters are set to nil, they are given their default values.
  #--------------------------------------------------------------------------
  def initialize(x = 0, y = 0, width = Graphics.width / 2, height = Font.default_size + Window_Help.new(1).hide.padding * 2, capture_speed = 8, ignore_multiline = true, max = -1, arrows_visible = false)
    x ? nil : x = 0
    y ? nil : y = 0
    width ? nil : width = Graphics.width / 2
    height ? nil : height = Font.default_size + Window_Help.new(1).hide.padding * 2
    capture_speed ? nil : capture_speed = 9
    ignore_multiline ? nil : ignore_multiline = true
    max ? nil : max = -1
    arrows_visible ? nil : arrows_visible = false
    super(x, y, width, height)
    self.contents = Bitmap.new(self.contents.width * 40, self.contents.height)
    @alt = "0x"
    @callback = {}
    @capture_speed = capture_speed
    @cursor = 0
    @cursor_bitmap = Bitmap.new(Font.default_size, Font.default_size)
    @cursor_bitmap.fill_rect(0, 0, 2, @cursor_bitmap.height, Color.new(255, 255, 255, 255))
    @cursor_sprite = Sprite.new
    @cursor_sprite.bitmap = @cursor_bitmap
    @ignore_multiline = ignore_multiline
    @keys = Hash.new {|h, k| h[k] = 0}
    @last_cursor = 0
    @last_text = ""
    @max = max
    self.arrows_visible = arrows_visible
    @text = ""
    update_cursor(true)
    ZKey::Fast_Keys.each{ |k|
      @keys[k] = -2 # These keys are not subject to a wait between presses.
    }
    deactivate
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Process_key                                    NEW METHOD
  #  * Process_key handles all the input for the script. System keys are
  #  * specially handled for their unique functions, while some key
  #  * key combinations (such as CTRL + V) are handled for their function.
  #  * Normal keys are simply added into the text at the cursor's location.
  #--------------------------------------------------------------------------
  def process_key(key, syskey, upper, upper_s)
    if key == nil
      return
    end
    
    # Unicode characters
    if @max > @text.size || @max < 0
      if ZKey.press?(:_alt) && @alt.size < 8
        if ["1", "2", "3", "4", "5", "6", "7", "8" ,"9" ,"0"].include?(key)
          @alt += key.to_s
          @keys[syskey] = 50
          return
        elsif ["a", "b", "c", "d", "e", "f"].include?(key)
          @alt += key.upcase
          @keys[syskey] = 50
          return
        end
      elsif @alt.size == 8
        @text.insert(@cursor, [@alt.to_i(16)].pack("U*"))
        @alt = "0x"
        @cursor += 1
      end
    end
    
    # Clipboard functions
    if ZKey.press?(:_control)
      if ZKey.press?(:_v) && @keys["clipboard"] == 0 && (@max > @text.size || @max < 0)
        text = Clipboard.GetText
        if @ignore_multiline == true
          if text[text.size] == "\n"
            text[text.size - 1, 1] = ""
          end
        else
          text = remove_newline(text)
        end
        if @text.size + text.size > @max && @max > 0
          text = text[0, @max - @text.size]
        end
        @text.insert(@cursor, text)
        @cursor += text.size
        @keys["clipboard"] = 100
        return
      elsif ZKey.press?(:_c)
        Clipboard.SetText(@text)
        @keys["clipboard"] = 100
        return
      end
    end
    
    case key
      when "$$BACK"
        if @cursor > 0
          @cursor -= 1
          if self.ox > 0
            self.ox -= self.text_size(@text[@cursor]).width
          end
          @text[@cursor, 1] = "" # Set the key to nil
        end
      when "$$DELETE"
        if @cursor < @text.size
          if self.ox > 0
            self.ox -= self.text_size(@text[@cursor]).width
            @last_cursor = -1 # Update the cursor's position, since delete doesn't change it.
          end
          @text[@cursor, 1] = "" # Set the key to nil
        end
      when "$$ENTER"
        if @text == ""
          return
        end
        if @run == true
          @accepted = true
        else
          self.deactivate
          @callback["success"].class == Method ? @callback["success"].call(@text) : nil
          @fiber = nil
        end
      when "$$ESCAPE"
        @callback["failure"].class == Method ? @callback["failure"].call : nil
      when "$$END"
        @cursor = @text.size
      when "$$HOME"
        @cursor = 0
      when "$$LEFT"
        if @cursor > 0
          @cursor -= 1
        end
        @callback["arrow"].class == Method ? @callback["arrow"].call("$$LEFT") : nil
      when "$$RIGHT"
        if @cursor < @text.size
          @cursor += 1
        end
        @callback["arrow"].class == Method ? @callback["arrow"].call("$$RIGHT") : nil
      when "$$UP"
        @callback["arrow"].class == Method ? @callback["arrow"].call("$$UP") : nil
      when "$$DOWN"
        @callback["arrow"].class == Method ? @callback["arrow"].call("$$DOWN") : nil
    else
      if (@text.size >= @max && @max > 0) || key.include?("$$") # text is too long or catch unhandled system key
        return
      end
      if upper == true
        if upper_s == true && ZKey::Special_Characters.include?(key)
          @text.insert(@cursor, ZKey::Special_Characters[key]) # Get the key in ASCII, then get the 'uppercase' of the special key.
        else
          if !key.is_a?(Numeric)
            @text.insert(@cursor, key.upcase) # Just get the key and capitalize it.
          else
            @text.insert(@cursor, key)
          end
        end
      else
        if upper_s == true && ZKey::Special_Characters.include?(key)
          @text.insert(@cursor, ZKey::Special_Characters[key])
        else
          @text.insert(@cursor, key) # Just get the key and put it in.
        end
      end
      @cursor += 1 # increase the index so it goes on.
    end
    
    @keys[syskey] == 0 ? @keys[syskey] = 50 : @keys[syskey] == -2 ? nil : @keys[syskey] = 4 
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Remove_newline                                 NEW METHOD
  #  * Remove_newline will remove all \n characters from text that will be
  #  * pasted into the window, if the ignore_multiline option is set to true.
  #--------------------------------------------------------------------------
  def remove_newline(text)
    result = ""
    text.each_char { |c|
      if c == "\n"
        next
      else
        result += c
      end
    }
    return result
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Resize_text                                    NEW METHOD
  #  * Resize_text will break the supplied text up into an array that will
  #  * fit into the specified width. This version does not split words
  #  * by spaces, but rather in the last spot needed before a new line must
  #  * begin, because splitting on whitespace is not needed for this script.
  #--------------------------------------------------------------------------
  def resize_text(text, window_w)
    temp = ""
    result = []
    text.each_char { |c|
      if self.text_size(temp + c).width + 4 > window_w
        result.push(temp)
        temp = c
      else
        temp += c
      end
    }
    result.push(temp)
    temp = nil
    return result
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: run                                            NEW METHOD
  #  * Run will prepare and loop through the input method to get keys
  #  * pressed by the user. This method was mostly designed for use in
  #  * events, but it should also function for scenes.
  #--------------------------------------------------------------------------
  def run(variable = 0)
    activate
    @run = true
    Graphics.transition
    loop do
      update
      Graphics.update
      if ZKey.press?(:_esc)
        @accepted = false
        @callback["failure"].class == Method ? @callback["failure"].call : nil
      end
      if @accepted != nil
        break
      end
    end
    if @accepted == false
      @text = -1
    end
    @run = false
    deactivate
    if variable.between?(1, 5000)
      $game_variables[variable] = @text
      return
    else
      return @text
    end
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: set_callback                                   NEW METHOD
  # * Set_callback gets a method, m, which will be called when specific
  # * conditions are met. Currently, the callback conditions available are:
  #  * Success - The user pressed enter, accepting their input.
  #  * Failure - The user pressed escape, canceling their input altogether.
  #
  # * Callback types should be strings. i.e. "success" or "failure". Casing
  # * does not matter.
  #--------------------------------------------------------------------------
  def set_callback(type, m)
    m.class == Method ? nil : (return false)
    @callback == nil ? @callback = Hash.new{|h,k| h[k] = nil} : nil
    @callback[type.downcase] = m
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Set_display                                    NEW METHOD
  # * Set_display will set how the characters should be drawn on the window.
  # * This could be used to set the characters to stars for inputting a
  # * password.
  #--------------------------------------------------------------------------
  def set_display(type)
    type.is_a?(String) ? @display = type : nil
  end
  
  #--------------------------------------------------------------------------
  # Window_Textbox: Update                                         NEW METHOD
  #  * Update manages the window's control flow. If the window is not the
  #  * currently active one, it will only call Window_Base's update method.
  #  * Otherwise, it will check for the existence of the fiber that gets
  #  * and handles input, creates one if there isn't, checks for the escape
  #  * key (if the run method was called), checks the status of Alt
  #  * characters, and finally updates the window's scroll, text, and cursor.
  #--------------------------------------------------------------------------
  def update
    super
    if self.active == true
      if @fiber
        @fiber.resume rescue puts caller.join("\n")
      else
        @fiber = Fiber.new {get_keys}
        @fiber.resume
      end
      if ZKey.press?(:_esc) && @run == true
        shutdown
      end
      if !ZKey.press?(:_alt) && @alt != "0x" # No alt key is pressed, and @alt is not empty.
        @text.insert(@cursor, [@alt.to_i(16)].pack("U*"))
        @alt = "0x"
        @cursor += 1
      end
      update_scroll
      update_window
      update_cursor
    end
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Update_cursor                                  NEW METHOD
  #  * Update_cursor repositions the cursor based on its current position in
  #  * the window's text. It will hide itself if it is not currently in the
  #  * window's contents area. This is because the cursor is not drawn on
  #  * the window itself, but rather is a separate sprite that is
  #  * repositioned when needed.
  #--------------------------------------------------------------------------
  def update_cursor(force = false)
    if @cursor != @last_cursor || @cursor_sprite.x < self.contents_width || @cursor_sprite.x > self.contents_width || force == true 
      @cursor_sprite.y = y + self.padding
      if (self.text_size(@text[0, @cursor]).width + self.padding - ox).between?(self.x + self.padding, self.width - self.padding)
        if @cursor_sprite.visible == false
          @cursor_sprite.visible = true
        end
        @cursor_sprite.x = self.text_size(@text[0, @cursor]).width + self.padding - self.ox
      else
        if @cursor_sprite.visible == true
          @cursor_sprite.visible = false
        end
      end
      @last_cursor = @cursor
    end
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Update_scroll                                  NEW METHOD
  #  * Update_scroll ensures that the textbox is always looking at where the
  #  * cursor is.
  #--------------------------------------------------------------------------
  def update_scroll
    if self.text_size(@text[0, @cursor]).width < self.ox # If the cursor is to the LEFT of the window
      self.ox -= self.text_size(@text[@cursor]).width
    elsif self.text_size(@text[0, @cursor]).width > self.contents_width + self.ox # if the cursor is to the RIGHT of te window
      self.ox += self.text_size(@text[@cursor] == nil ? @text[@cursor - 1] : @text[@cursor]).width
    end
    if self.ox < 0 # If we scroll passed the left boundary (the vertical axis)
      self.ox = 0
    end
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Update_window                                  NEW METHOD
  #  * Update_window handles the drawing of the text into the textbox. It
  #  * uses the resize_text method is necessary to be able to fit all the
  #  * text into itself properly.
  #--------------------------------------------------------------------------
  def update_window
    if @last_text != @text && @display != "none"
      contents.clear
      if self.text_size(@text).width > self.contents_width
        x = 0
        text = resize_text(@text, self.contents_width)
        text.each { |str|
          msg = str
          @display == "star" ? (msg = "*" * str.length) : nil
          draw_text(x, 0, self.text_size(str).width + 4, Font.default_size, msg)
          x += self.text_size(str).width
        }
      else
        draw_text(0, 0, self.text_size(@text).width + 10, Font.default_size, @text)
      end
      @last_text = @text.clone
    end
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Shutdown                                       NEW METHOD
  #  * Shutdown will operate differently depending on whether the window is
  #  * running from having get_input called. If it is, the text is set to
  #  * -1, meaning that the user canceled text input, and @accepted is set
  #  * to false, allowing the get_input method to leave it's loop.
  #  * If the method is run without get_input, however, it empties the text
  #  * and deactivates the window.
  #--------------------------------------------------------------------------
  def shutdown
    if @run == true
      @text = -1
      @accepted = false
    else
      @text = ""
      deactivate
    end
  end
  
  #--------------------------------------------------------------------------
  # Window_TextBox: Wait                                           NEW METHOD
  #  * Wait will yield the fiber that continually grabs key presses so that
  #  * it doesn't register multiple characters on one keypress.
  #--------------------------------------------------------------------------
  def wait(duration)
    duration.times { Fiber.yield }
  end
  
end

class Scene_Map < Scene_Base
  #--------------------------------------------------------------------------
  # Scene_Map: Call_menu                                       ALIASED METHOD
  #  * Call_menu brings up the main menu when the escape key is pressed in
  #  * game. this method is aliased to disable the menu when a TextBox window
  #  * currently exists. This was made for events, as cancelling them with
  #  * the escape key brought up the menu.
  #--------------------------------------------------------------------------
  alias zale_wintb_callmenu_4y7dm2idmwe call_menu
  def call_menu
    if Scene_Base.instance_variables.any? {|var| var.is_a?(Window_TextBox)}
      return
    end
    zale_wintb_callmenu_4y7dm2idmwe
  end
end
