#+============================================================================+#
# Script: Console
# Version: 1.1.0
# Last Update: December nth, 2013
# Author: Zalerinian (~ZF)
#==============================================================================#
# Version History
#  1.0.0 (July 25th, 2013)
#   - Initial release.
#
#  1.1.0 (Date)
#   What's New
#    - Text displayed in the log window will now split at a completed word,
#      rather than just where the separate letters fit.
#
#    - Removed the $zconsole variable by placing everything needed in
#      Game_Temp.
#   
#    - You may now specify the position of the edit window, which will resize
#      and reposition the log window.
#   
#    - The FPS counter is now an accurate representation of how many frames have
#      passed.
#   
#    - Added runnable scripts!
#   
#    - Removed editable window into the Window_TextBox script, rather than both
#      having their own version, they will now both use that one.
#      * What's missing *
#       - Clipboard Module (Integrated into Window_TextBox)
#       - ZKey Module (Integrated into Window_TextBox)
#         Scene_Console
#         - get_input
#         - process_key
#         - update_cursor
#         - update_window
#   
#   - Improved the accuracy of input overall
#
#
#   Bug fixes
#    - using 'set' for player speed would cause you to have a movespeed of 0.
#    - Scrolling the text window when it wasn't full has been fixed.
#    - The game would crash when using a number key with capslock on
#
#
#==============================================================================#
# Support
#  For support, bug reports, or feedback, please email scripts@razelon.tk,
#  or send me (Zalerinian) a private message (PM) on the RPG maker forums.
#==============================================================================#
# Credit
#  I do not require credit to be given. You may use this script in a
#  commercial or non-commercial game, so long as you do not claim that
#  you wrote it.
#==============================================================================#
# Method List
# + = new method; * = aliased method
#
#
#
#   Scene_Base
#    · * Update
#    · + console_can_open?
#
#   SceneManager
#    · + last_scene_class
#
#   DataManager
#    · * create_game_objects
#
#
#   + Scene_Console
#    · + build_commands
#    · + console_can_open?
#    · + get_commands
#    · + help
#    · + resize_text
#    · + shutdown
#    · + start
#    · + terminate
#    · + wait
#    · + update
#    · + update_cmd
#    · + update_log
#    · + update_scroll
#    · + prompt_password
#    · + add_message
#    · + add_command
#    · + give
#    · + clear
#    · + list
#    · + gold
#    · + speed
#    · + toggle
#    · + check
#    · + kill
#    · + transfer
#    · + moveto
#    · + cme
#    · + level
#    · + switch
#    · + variable
#
#   Game_Map
#    · * update_interpreter
#
#   Game_Event
#    · * lock
#    · * update
#    · + sttr_reader page; event
#
#   Sprite_Character
#    · * initialize
#    · * update_bitmap
#
#   Game_Character
#    · * attr_accessor move_speed
#
#   Game_Player
#    · * encounter
#    · * debug_through?
#
#   Scene_Base
#    · * update
#
#   Game_Troop
#    · * gold_total
#    · * make_drop_items
#    · * exp_total
#==============================================================================#
# Usage
#  The console is a plug-n-play script that allows players to use cheats,
#  or assists the developer with debugging.
#==============================================================================#
# Configuration:
#==============================================================================#
module Zale
  module Console
    Require_password_Playtest = true
    # If set to true, require a password when opening the console during
    # playtesting. The password is configured below. It is highly recommended
    # that you have this set to true.
    
    
    Require_password_Normal = false
    # If set to true, the console will need a password to be opened when
    # running out of a playtest. The password is configured below.
    
    
    Password_Playtest  = "\u0001"
    # Specify a password to protect the console when running the game in test
    # mode. The console has increased power while testplaying the game, so
    # a password is necessary to protect the game. The default password is a
    # Unicode character, '☺'. To specify Unicode characters, use a backslash
    # '\', followed by a 'u', and then the code. Include leading 0's. For
    # example, setting the password to the ♥ character would be \u0003
    
    
    Password_Normal = "\u0002"
    # Specify a password to protect the console from being used outside of a
    # playtest. This DOES NOT protect the console during a playtest. Unicode
    # setup is the same as above.
    
    
    Show_stars = false
    # If set to true, the asterisk (star, *) character will be put in place
    # of each character in the password. Otherwise, the password will not
    # be visible at all (The textbox will appear blank)
    
    
    Always_require_password = false
    # If set to true, the password will need to be put in every time the console
    # is closed. If set to false, the password only needs to be put in once
    # while the game is running.
    
    
    Open_key = :_tilde # ` key (to the left of 1)
    # What button will open the console. The list of keys is available in the
    # ZKey module below.
    
    
    Blocked_scenes = []
    # Scenes where the console is not allowed to be opened.
    
    
    Override_bscenes = false
    # Ignore the blocked scenes during playtesting?
    
    
    Block_switch = 99
    # When this switch is set ON, the console cannot be opened.
    
    
    Override_bswitch = false
    # Ignore the block switch during playtesting?
    
    
    Unblock_switch = 98
    # Set this switch to ON to allow the console during a blocked scene,
    # since you may not want it blocked at all times, but do not want to
    # use the Block Switch. This overrides the block switch and blocked
    # scenes, and can be used outside of a playtest.
    
    
    IDs_in_list = true
    # Display the item/weapon/armor/skill/state ID when listing them?
    # The ID is used to give the player items, weapons, etc.

    
    Custom_windowskin = false
    # Use a custom windowskin for the console windows?
    
    
    Windowskin = "console"
    # The windowskin's name. Only applies if the above option is true.
    
    Editbox_Y = Graphics.height / 2 - 24
    # This is the top position of the textbox that you type into.
    # Changing this position will reposition and resize the log window.
    
    Low_Framerate = Graphics.frame_rate / 4
    # At what frame rate will we consider the game to be running slowly,
    # and display the FPS counter in a red color?
    
    Runnable_Extension = "run"
    # A file with this extension (file.extension) can be used to run a
    # series of calls in one. Additional security for runnable scripts
    # can be configured below.
    
    Require_Runnable_Key = true
    # If this is set to true, any runnable file will require a key in
    # the file's header in order to run. If the key is not found, the
    # runnable will be ignored.
    
    Runnable_Key = "Your Secret Key"
    # If the above option is true, the key set here will need to be
    # present in the header of any runnable file. If this key is not
    # found, or is not correctly input, the file will not be run. It
    # is recommended that you change this key.
    
    Restrict_Runnable_Access = true
    # If this option is set to true, runnable files will only be run
    # if the game is launched in playtest mode. This is not a great
    # security feature, but it can prevent some people from running
    # a script they shouldn't be. It is recommended you use a key
    # prevent users from using runnable scripts.
  end
end

$imported = {} if $imported.nil?
$imported["ZF Console"] = 1.10

module Clipboard
  # Clipboard functions
  OpenClipboard = Win32API.new('user32', 'OpenClipboard', ['I'], 'I');
  CloseClipboard = Win32API.new('user32', 'CloseClipboard', [], 'I');
  EmptyClipboard = Win32API.new('user32', 'EmptyClipboard', [], 'I');
  GetClipboardData = Win32API.new('user32', 'GetClipboardData', ['I'], 'I');
  SetClipboardData = Win32API.new('user32', 'SetClipboardData', ['I', 'I'], 'I');
  Alloc = Win32API.new('kernel32', 'GlobalAlloc', ['I','I'], 'I');
  Lock = Win32API.new('kernel32', 'GlobalLock', ['I'], 'P');
  Unlock = Win32API.new('kernel32', 'GlobalUnlock', ['I'], 'I');
  Len = Win32API.new('kernel32', 'lstrlenA', ['P'], 'I');
  Copy = Win32API.new('kernel32', 'lstrcpyA', ['I', 'P'], 'P');
  LockI = Win32API.new('kernel32', 'GlobalLock', ['I'], 'I');
  
  
  #--------------------------------------------------------------------------
  # Clipboard: GetText                                             NEW METHOD
  #  * This method will get the text currently on the users clipboard and
  #  * return it.
  #--------------------------------------------------------------------------
  def self.GetText
    result = ""
    if OpenClipboard.Call(0) != 0
      if (h = GetClipboardData.Call(1)) != 0
        if (p = Lock.Call(h)) != 0
          result = p;
          Unlock.Call(h);
        end
      end
      CloseClipboard.Call;
    end
    return result;
  end
  
  #--------------------------------------------------------------------------
  # Clipboard: SetText                                             NEW METHOD
  #  * This will allow you to set the text of the clipboard so that the user
  #  * may paste information elsewhere.
  #--------------------------------------------------------------------------  
  def self.SetText(text)
    if (text == nil) || (text == "")
      return
    end
    if OpenClipboard.Call(0) != 0
      EmptyClipboard.Call();
      len = Len.Call(text);
      hmem = Alloc.Call(0x2000, len+1);
      pmem = LockI.Call(hmem);
      Copy.Call(pmem, text);
      SetClipboardData.Call(1, hmem);
      Unlock.Call(hmem);
      CloseClipboard.Call;
    end
  end
end

class Scene_Base
  
  #--------------------------------------------------------------------------
  # Scene_Base: console_can_open?                                  NEW METHOD
  #  * This method runs multiple checks to see if the console is allowed to
  #  * open. It checks the block switch, the blocked scenes, the unblock
  #  * switch, the block overrides, and that the console isn't currently
  #  * open.
  #--------------------------------------------------------------------------
  def console_can_open?
    if ZKey.press?(Zale::Console::Open_key)
      if $game_switches[Zale::Console::Block_switch] == false || Zale::Console::Override_bswitch == true && $TEST == true || $game_variables[Zale::Console::Unblock_switch] == true
        if !(Zale::Console::Blocked_scenes.include?(SceneManager.scene.class)) || Zale::Console::Override_bscenes == true && $TEST == true || $game_switches[Zale::Console::Unblock_switch] == true
          return true
        end
      end
    end
    return false
  end

  alias zale_ConsoleUpdate_sk57gk45ifj update
  #--------------------------------------------------------------------------
  # Scene_Base: Update                                         ALIASED METHOD
  #  * Call the console from any scene if you press the open key and it's
  #  * allowed to open.
  #  * The update method also adds an FPS counter, if it is toggled in the
  #  * console. It is not the most accurate counter, but you'll know when you
  #  * start to lag.
  #--------------------------------------------------------------------------
  def update
    zale_ConsoleUpdate_sk57gk45ifj
    if console_can_open? == true && SceneManager.scene_is?(Scene_Console) == false
      SceneManager.call(Scene_Console)
    end
  end
  
  alias zale_sbase_console_cgo_ghy81bgja0 check_gameover
  #--------------------------------------------------------------------------
  # Scene_Base: check_gameover                                 ALIASED METHOD
  #  * Check_gameover checks to see if the player is dead, and then to end 
  #  * the game, but if we have invulnerability set, then this doesn't 
  #  * matter, so we do nothing.
  #--------------------------------------------------------------------------
  def check_gameover
    if $game_temp != nil && $game_temp.invuln == false
      zale_sbase_console_cgo_ghy81bgja0
    elsif $game_temp != nil && $game_temp.invuln == true
      nil
    else
      zale_sbase_console_cgo_ghy81bgja0
    end
  end
  
end

module SceneManager
  #--------------------------------------------------------------------------
  # SceneManager: last_scene_class                                  NEW METHOD
  #  * returns the class of the last scene
  #--------------------------------------------------------------------------
  def self.last_scene_class
    if @stack.size < 1
      return
    end
    @stack[@stack.size - 1].class
  end
end

module Graphics
  @fps_counter, @fps_counter_ary = 0, []
  class << self
    alias zale_graphics_console_fps_update_g86habdhek update
  end
  
  #--------------------------------------------------------------------------
  # Graphics: update                                           ALIASED METHOD
  #  * Update will update the game's screen, as well as manage the FPS 
  #  * counter that we can toggle on and off.
  #--------------------------------------------------------------------------
  def self.update
    time = Time.now
    zale_graphics_console_fps_update_g86habdhek
	  @fps_counter_ary[frame_count % frame_rate] = Time.now != time
	  @fps_counter = 0
	  frame_rate.times {|i| @fps_counter += 1 if @fps_counter_ary[i]}
    if $game_temp != nil
      $game_temp.refresh_fps(@fps_counter)
    end
  end
end

class Scene_Console < Scene_Base
  Keyboard = Win32API.new("user32.dll", "keybd_event", "nnnn", "v")
  #--------------------------------------------------------------------------
  # Scene_Console: build_commands                                  NEW METHOD
  #  * Builds the command list for the console. Each command is stored as an
  #  * array, where the first element is the method, and the second is a
  #  * boolean value on whether it can only be used during a playtest.
  #--------------------------------------------------------------------------
  def build_commands
    @commands = {}
    @commands["speed"]        = [method(:speed),       false]
    @commands["toggle"]       = [method(:toggle),      false]
    @commands["give"]         = [method(:give),        false]
    @commands["list"]         = [method(:list),        false]
    @commands["help"]         = [method(:help),        false]
    @commands["kill"]         = [method(:kill),        false]
    @commands["transfer"]     = [method(:transfer),    false]
    @commands["moveto"]       = [method(:moveto),      false]
    @commands["clear"]        = [method(:clear),       false]
    @commands["level"]        = [method(:level),       false]
    @commands["restart"]      = [method(:restart),     false]
    @commands["_restart"]     = [method(:_restart),    false]
    @commands["run"]          = [method(:run),         false]
    @commands["check"]        = [method(:check),       true ]
    @commands["cme"]          = [method(:cme),         true ]
    @commands["switch"]       = [method(:switch),      true ]
    @commands["variable"]     = [method(:variable),    true ]
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: console_can_open?                               NEW METHOD
  #  * This method runs checks to see if the console is allowed to open. It
  #  * checks to see if the scene we are in is not allowed to open the
  #  * console, it checks the block switch, the unblock switch, and the
  #  * override switches.
  #--------------------------------------------------------------------------
  def console_can_open?
    if $game_switches[Zale::Console::Block_switch] == false || Zale::Console::Override_bswitch == true && $TEST == true || $game_variables[Zale::Console::Unblock_switch] == true
      if !(Zale::Console::Blocked_scenes.include?(SceneManager.scene.class)) || Zale::Console::Override_bscenes == true && $TEST == true || $game_switches[Zale::Console::Unblock_switch] == true
        return true
      end
    end
  return false
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: get_commands                                    NEW METHOD
  #  * The get_commands method displays the list of available commands based
  #  * on whether or not the command requires the game to be in playtesting
  #  * mode. If it is, all commands a re returned, if not, only those that
  #  * do not require 'elevated' permissions.
  #--------------------------------------------------------------------------
  def get_commands
    if $TEST == true
      @commands.keys
    else
      cmds = []
      @commands.each_pair { |key, ary|
        if ary[1] == false
          cmds.push(key)
        end
      }
      cmds
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: help                                            NEW METHOD
  #  * The help command displays help text so that players and developers can
  #  * use the console correctly.
  #--------------------------------------------------------------------------
  def help(*args)
    type = args[0]
    if type.is_a?(String)
      type.downcase!
    end
    
    if type == "" || type == nil
      @messages.unshift(
"The console window supports scrolling so that you may see text displayed earlier. Press the CTRL key and hold the up or down arrow key to scroll the window. Try scrolling down now.


To get help on a certain command, type the command name after the help command. The available commands are:

#{get_commands.join(",  ") }
")
    end
    
    if type == "speed" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The speed command allows you to alter how fast you move. To increase your speed, simply input the command, followed by a whole number. If the number is positive, you will move faster (there is a limit). If the number is negitive, you will move slower.

speed <number>
")
  end
  
    if type == "toggle" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The toggle command allows you to modify many aspects of the game. You can completely disable the processing of the AI, disable ones selectively, or even toggle fullscreen. To toggle a feature, input 'toggle', followed by the feature. The features you can edit are:

ai, ids, noclip, fps, battle_gains, fullscreen, cai, separate AIs(input their ID, which can be found by toggling IDs), and
invulnerability(invuln, invin, invulnerable, invincible, or invulnerability).

'ai' will turn on/off all event processing, freezing any movement except for the player.
'ids' will turn on/off an event's id, floating above it.
'noclip' will enable/disable walking anywhere on the map, regardless of regular passability settings.
'fps' will display a number in the top left corner. A lower number means a slower speed.
'battle_gains' will give you the rewards from battle from enemies killed with the 'kill' command.
'fullscreen' will turn on/off fullscreen.
'cai' will toggle any possible random encounters.
Any separate id will turn on/off that specific event. IDs can be found by enabling hovering ids.
'invulnerability' (or invuln/invin/invulnerable/invincible) will prevent the player from dying.
")
    end
    
    if type == "give" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The give command will grant you any armor, item, or weapon. To get them, type 'give' followed by the type, armor (armour), item, or weapon, then the ID, which can be found by using list. Optionally, you can specify an amount.

give <type> <id> [amount]
")
    end
    
    if type == "list" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The list command will print out a 3-column list of a dataset. Available datasets are:

items, armo(u)rs, weapons, states, skills, actors, or enemies.

list <type>
")
    end
    
    if type == "help" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The help command displays help on a specific command, or general help about the console.
")
    end
    
    if type == "kill" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"During a battle, the kill command can be used to remove enemies from the field. To remove them, input 'kill', followed by a number to represent the enemy. The IDs are not constant, and change as enemies are killed or deleted. Alternatively, you may specify 'all' to kill all the enemies on the field.

kill <number|all>
")
    end
    
    if type == "transfer" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The transfer command allows you to change the map you are currently in. To change maps, input 'transfer', followed by the map ID, x, and y coordinates.

transfer <id> <x> <y>
")
    end
    
    if type == "moveto" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"Similarly to transfer, the moveto command will move you to the specified coordinate in the current map.

moveto <x> <y>
")
    end
    
    if type == "clear" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The clear command will erase the console log. This command has no arguments.
")
    end
    
    if type == "level" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The level command will allow you to alter the level of your characters. Input 'level', followed by the actor's ID (can be found by using 'list actors'), and then the number of levels you wish to advance (positive), or retreat (negative).

level <amount>
")
    end
    
    if type == "check" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The check command will allow you to determine if the currently running AIs (events) have parallel process or autorun pages. You may also specify 'all' to check if it has an autorun or parallel process page ever.

check [all]
")
    end
    
    if type == "cme" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The cme command will allow you to run a Common Event. Specify the common event's ID for it to run

cme <id>
")
    end
    
    if type == "switch" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The switch command will allow you to change the state of a switch. Specify 'on' or 'true' to activate the switch, or 'off' or 'false' to deactivate it. The switch ID is the first parameter.

switch <id> <on|true  |  off|false>
")
    end
    
    if type == "variable" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift(
"The variable command allows you to alter the variables stored in the game. Specify the ID first, and the amount to change the variable second. If the amount is negative, the amount will be subtracted. You may only add and subtract the variables.

variable <id> <amount>
")
    end
    
    if type == "restart" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift
("The restart command will reset the game, bringing you back to the title screen. No data is saved, so
any progress you have made since you last saved will be lost.
")
    end
    
    if type == "_restart" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @message.unshift
("The _restart command will reset the current scene. If the scene has gotten stuck, this command will attempt
to reset it back to the beginning.
")
    end
  
    if type == "exit" && (@commands[type][1] == true && $TEST == true || @commands[type][1] == false)
      @messages.unshift
("The exit command will close the game, without saving any data. Be sure to save the game before running this command.
")
    end
    
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: process_arrow                                   NEW METHOD
  #  * Process_arrow handles display scrolling, ensuring the content is 
  #  * always on the screen, and that previous content can be viewed.
  #--------------------------------------------------------------------------
  def process_arrow(key)
    case key
    when "$$UP"
      if @cmd_index < @cmd.size - 1 && !ZKey.press?(:_control)
        @cmd_index += 1
        @edit.text = @cmd[@cmd_index].clone
        @edit.cursor = @edit.text.length
      elsif ZKey.press?(:_control)
        if @message_y > @display.contents_height
          if @display.oy - 4 < 0
            @display.oy = 0
          else
            @display.oy -= 4
          end
        end
      end
    when "$$DOWN"
      if @cmd_index > 0 && !ZKey.press?(:_control)
        @cmd_index -= 1
        @edit.text = @cmd[@cmd_index].clone
        @edit.cursor = @edit.text.length
      elsif ZKey.press?(:_control)
        if @message_y > @display.contents_height
          if @display.oy + 4 > (@message_y - @display.contents_height + @display.text_size("a").height) && @message_y > @display.contents_height
            @display.oy = @message_y - @display.contents_height + @display.text_size("a").height
          else
            @display.oy += 4
          end
        end
      end
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: process_command                                 NEW METHOD
  #  * Handles the processing of commands typed in by the user
  #--------------------------------------------------------------------------
  def process_command(text)
    if $game_temp.pass_in == false
      if text == "" && @pass != ""
        return
      end
      if text == @pass
        @pass_accepted = true
      else
        @pass_accepted = false
      end
      return
    end
    if text == ""
      return
    end
    begin
      @cmd.insert(1, text)
      commands = text.clone.split(" ")
      cmd = commands.delete_at(0)
      if @commands.keys.include?(cmd)
        if @commands[cmd][1] == true && $TEST == true || @commands[cmd][1] == false
          @commands[cmd][0].call(*commands)
        end
      else
        @messages.unshift("Unknown command \"#{cmd}\"")
        reset
        return -1
      end
    rescue Exception => e
      if e.class.to_s == "ArgumentError"
        ar_count = 0
        method(cmd.to_sym).parameters.each {|ary|
          if ary[0] == :req
            ar_count += 1
          end
        }
        @messages.unshift("Incorrect argument count. Supplied #{commands.size} out of #{ar_count}")
        reset
        return -2
      else
        @messages.unshift(
"The console has encountered an unexpected error running '#{cmd}'. Please locate your console manufacturer for assistance. An error log has been made. Please include the log with your report.
")
        if FileTest.exist?("Error.log") == false
          File.open("Error.log", "w+").close
        end
        log   = File.open("Error.log", "r+")
        data = log.readlines
        log.close
        error = File.open("Error.log", "w+")
        m = method(cmd.to_sym).parameters rescue "Unkown Command"
        error.write("Version:\t1.0.0\nDate:\t\t#{Time.now}\nCommand:\t#{cmd}\nParameters:\t#{m}\nArguments:\t#{commands}\nError:\t\t#{e.message}\n\nBacktrace:\n")
        scripts = load_data('Data/Scripts.rvdata2').collect {|s| s[1]}
        e.backtrace.each{ |str|
          error.write(str.gsub!(/{(.*)}(.*)/) {"\t#{scripts[$1.to_i] + $2}\n"})
        }
        error.write("\n\n")
        data.each { |d|
          error.write(d)
        }
        error.close
        puts $!.inspect
        reset
        return -3
      end
    end
  reset # reset the window for more text.
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: reset                                           NEW METHOD
  #  * Reset will restore the window back to an empty text box.
  #--------------------------------------------------------------------------
  def reset
    @cmd_index = 0
    @display.oy = 0
    @edit.text = "" # clear the text
    @edit.ox = 0 # Reset the scroll to the original position
    @edit.cursor = 0 # Reset cursor position
    @edit.activate
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: resize_text                                     NEW METHOD
  #  * Returns an array with the text resized to fit the supplied width.
  #--------------------------------------------------------------------------
  def resize_text(text, window_w)
    temp = ""
    result = []
    text.split("\n").each { |set|
      set.split(" ").each{ |word|
        if @win.text_size(temp + " " + word).width + 4 > window_w 
          result.push(temp)
          temp = word
        else
          temp += "#{temp == "" ? "" : " "}#{word}"
        end
      }
      result.push(temp)
      temp = ""
    }
    result.push(temp)
    temp = nil
    result
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: shutdown                                        NEW METHOD
  #  * Closes the console window.
  #--------------------------------------------------------------------------
  def shutdown
    SceneManager.return
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: start                        SUPER: Scene_Base  NEW METHOD
  #  * The beginning of the scene. First, check if we are allowed to run.
  #  * If not, close, otherwise, build all the objects, check if we need
  #  * a password, if we do, ask for it, and correctly place the cursor.
  #--------------------------------------------------------------------------
  def start
    super
    if console_can_open? == false
      shutdown
    end
    @win = Window_Help.new(1).hide # Used for measurements
    @alt = "0x"
    @background_sprite = Sprite.new
    @background_sprite.bitmap = SceneManager.background_bitmap
    @background_sprite.color.set(16, 16, 16, 128)
    @cmd = [""]
    @cmd_index = 0
    @edit = Window_TextBox.new(0, Zale::Console::Editbox_Y, Graphics.width, @win.height)
    @edit.set_callback("success", method(:process_command))
    @edit.set_callback("failure", method(:shutdown))
    @edit.set_callback("arrow",   method(:process_arrow))
    @edit.activate
    @display = Window_Base.new(0, @edit.y + @edit.height, Graphics.width, Graphics.height - (@edit.y + @edit.height))
    @display.oy = 0
    @display.contents = Bitmap.new(@display.contents_width, @display.contents_height * 30)
    if Zale::Console::Custom_windowskin == true
      @edit.windowskin = Cache.system(Zale::Console::Windowskin)
      @display.windowskin = Cache.system(Zale::Console::Windowskin)
    end
    @last_cmd_index = 0
    @last_messages = []
    @messages = []
    @message_y = 0
    build_commands
    if Zale::Console::Require_password_Playtest == true && $game_temp.pass_in == false || Zale::Console::Always_require_password == true && $TEST == true
      if prompt_password(Zale::Console::Password_Playtest.to_s, false, Zale::Console::Show_stars, "unlock the console.") == false
        SceneManager.return
      end
    elsif Zale::Console::Require_password_Normal == true && $game_temp.pass_in == false|| Zale::Console::Always_require_password == true
      if prompt_password(Zale::Console::Password_Playtest.to_s, false, Zale::Console::Show_stars, "unlock the console.") == false
        SceneManager.return
      end
    else
      $game_temp.pass_in = true
    end
    reset
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: terminate                    SUPER: Scene_Base  NEW METHOD
  #  * Close the scene, and delete any objects that may linger.
  #--------------------------------------------------------------------------
  def terminate
    super
    @background_sprite.dispose
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: wait                                            NEW METHOD
  #  * Makes the input pause, so as to not catch multiple copies of one key
  #  * press.
  #--------------------------------------------------------------------------
  def wait(count)
    count.times { Fiber.yield }
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: update                       SUPER: Scene_Base  NEW METHOD
  #  * Update the scene. Create a fiber for getting input (this allows the 
  #  * pause), process unicode characters, and update all other parts.
  #--------------------------------------------------------------------------
  def update
    super
    @edit.update
    if ZKey.press?(:_esc) && $game_temp.pass_in == true
      shutdown
    end
    if !ZKey.press?(:_alt) && @alt != "0x"
      @text.insert(@cursor, [@alt.to_i(16)].pack("U*"))
      @alt = "0x"
      @cursor += 1
    end
    update_cmd
    update_log
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: update_cmd                                      NEW METHOD
  #  * Checks to see if the up or down arrow was pressed for command
  #  * history.
  #--------------------------------------------------------------------------
  def update_cmd
    if @last_cmd_index != @cmd_index
      if @cmd[@cmd_index] != nil
        @text = @cmd[@cmd_index].clone
        @last_cmd_index = @cmd_index
        @cursor = @text.size
      end
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: update_log                                      NEW METHOD
  #  * Display message into the log. List handling has been moved to 
  #  * print_list
  #--------------------------------------------------------------------------
  def update_log
    if @messages != @last_messages
      @display.contents.clear
      @message_y = 0
      @messages.each{ |info|
        if info =~ (/\$\$(\d+)List_(\w+)$/i)
          print_list($1.to_i, $2)
        else
          text = resize_text(info, @display.contents_width)
          text.each { |str|
            @display.draw_text(5, @message_y, @display.contents_width + 4, Font.default_size, str)
            @message_y += @win.text_size(str).height
          }
        end
        @message_y += Font.default_size
      }
      @last_messages = @messages.clone
    end
  end

  #--------------------------------------------------------------------------
  # Scene_Console: print_list                                      NEW METHOD
  #  * Print_list was previously integrated into update_log. It will make a 
  #  * list of the data requested by the user.
  #--------------------------------------------------------------------------
  def print_list(col, list)
    item_c = x = 0
    if ["ITEM", "ITEMS"].include?(list)
      data = $data_items
    elsif ["WEAPON", "WEAPONS"].include?(list)
      data = $data_weapons
    elsif ["ARMOR", "ARMORS", "ARMOUR", "ARMOURS"].include?(list)
      data = $data_armors
    elsif ["STATE", "STATES"].include?(list)
      data = $data_states
    elsif ["SKILL", "SKILLS"].include?(list)
      data = $data_skills
    elsif ["ACTOR", "ACTORS"].include?(list)
      data = $data_actors
    elsif ["ENEMY", "ENEMIES"].include?(list)
      data = $data_enemies
    end
    if data == nil
      @messages[0] = "Unable to display a list for '#{list}'"
      return
    end
    row_height = 0
    data.each{ |item|
      if item == nil || item.note.match(/<\s*no\s*list\s*>/i)
        next
      end
      item_c += 1
      row_height = @display.text_size(item.name).height > row_height ? @display.text_size(item.name).height : row_height
      @display.draw_text(x, @message_y, (@display.contents_width / col + 2), Font.default_size, "#{Zale::Console::IDs_in_list ? item.id.to_s + ". " : ""}#{item.name}")
      if x + @display.contents_width / col > @display.contents_width - @display.contents_width / col
        x = 0
      else
        x += @display.contents_width / col
      end
      if item_c % col == 0 && item_c != 0
        @message_y += (item.name == "" && Zale::Console::IDs_in_list ? @win.text_size(item.id.to_s).height : row_height) + 2
        row_height = 0
      end
    }
  end



# API Calls
# These calls allow the console to be extended by another developer

  #--------------------------------------------------------------------------
  # Scene_Console: prompt_password                            NEW METHOD  API
  #  * Requests a password from the user to ensure they won't do anything
  #  * too dangerous without a password to stop them.
  #--------------------------------------------------------------------------
  def prompt_password(pass = -1, no_message = false, stars = false, description = "")
    Graphics.transition
    if !SceneManager.scene_is?(Scene_Console)
      return
    end
    begin
      @pass = pass.to_s
    rescue
      raise "The supplied password is invalid."
    end
    $game_temp.pass_in = false
    @stars = stars
    if no_message == false
      if description == "" || description == nil
        @messages.unshift("You need a password to do that.")
      else
        @messages.unshift("You need a password to " + description + "#{description.end_with?(".") || description.end_with?("!") ? "" : "."}")
      end
    end
    loop do
      update
      if ZKey.press?(:_esc)
        @pass_accepted = -1
      end
      if @pass_accepted != nil
        break
      end
    end
    @stars = @pass = nil
    if @pass_accepted == true
      @messages = []
      @pass_accepted = nil
      $game_temp.pass_in = true
      return true
    elsif @pass_accepted == false
      @messages.unshift("Incorrect Password.")
      @pass_accepted = nil
      return false
    else
      shutdown
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: add_message                                NEW METHOD  API
  #  * Adds a message to the display window.
  #--------------------------------------------------------------------------
  def add_message(message)
    @messages.unshift(message.to_s)
  end

  #--------------------------------------------------------------------------
  # Scene_Console: add_commands                               NEW METHOD  API
  #  * Adds a command to the list, allowing the user to execute it.
  #--------------------------------------------------------------------------
  def add_command(name, method, elevated = false)
    method.class == Method ? nil : (return false)
    if @commads.is_a?(Hash) == false
      @commands = {}
    end
    @commands[name] = [method, elevated]
    true
  end
  
  
  
# Included Commands
# These commands are included by default to be used, either by the player or
# developer.

# For Developers looking to add more commands: Arguments will be passed in
# as the player types them, split by spaces. It is highly recommend you have
# a *args statement at the end of your method to ensure no argument errors
# are raised.
  
  
  #--------------------------------------------------------------------------
  # Scene_Console: item_get                                    NEW METHOD
  #  * Grants the player x amount of item y
  #--------------------------------------------------------------------------
  def give(type, id, count = 1, *args)
    if type == "armor" || type == "armour" || type == "armors" || type == "armours"
      item = $data_armors[id.to_i]
    elsif type == "item" || type == "items"
      item = $data_items[id.to_i]
    elsif type == "weapon" || type == "weapons"
      item = $data_weapons[id.to_i]
    else
      return
    end
    $game_party.gain_item(item, count.to_i)
  end

  #--------------------------------------------------------------------------
  # Scene_Console: clear                                           NEW METHOD
  #  * This clears the log window, making it empty again.
  #--------------------------------------------------------------------------
  def clear(*args)
    @messages = []
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: list                                            NEW METHOD
  #  * Sends a message to update_log to display a list of the specified
  #  * type. update_log handles the lists to ensure messages will not begin
  #  * to overlap each other.
  #--------------------------------------------------------------------------
  def list(type, *args)
    @messages.unshift("$$3List_" + type.to_s.upcase)
  end
  
  
  #--------------------------------------------------------------------------
  # Scene_Console: gold                                            NEW METHOD
  #  * Gives the party the specified amount of currency. If the number is
  #  * negative, the amount is subtracted from the party's wallet.
  #--------------------------------------------------------------------------
  def gold(amount, *args)
    $game_party.gain_gold(amount)
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: speed                                           NEW METHOD
  #  * This allows the player to alter their move speed. By default, it adds
  #  * the specified amount to their current speed. It also supports directly
  #  * setting the speed using 'set', followed by a number, or setting it
  #  * back to normal using the 'restore' command
  #--------------------------------------------------------------------------
  def speed(amount, *args)
    if amount == "set"
      $game_player.move_speed = args[0].to_i
    elsif amount == "restore"
      $game_player.move_speed = 4
    else
      $game_player.move_speed += amount.to_i
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: toggle                                          NEW METHOD
  #  * This command lets you toggle on or off multiple aspects of the game.
  #  * it currently supports all events, specific events, event IDS,
  #  * noclip, an FPS counter, gaining rewards from enemies killed through
  #  * the console during a battle, fullscreen, random encounters, and
  #  * invincibility
  #--------------------------------------------------------------------------
  def toggle(command, *args)
    if command.downcase == "ai"
      $game_temp.ai == true ? $game_temp.ai = false : $game_temp.ai = true
    elsif command.downcase == "ids"
      $game_temp.hover_ids == true ? $game_temp.hover_ids = false : $game_temp.hover_ids = true
    elsif command.downcase == "noclip"
      $game_temp.noclip == true ? $game_temp.noclip = false : $game_temp.noclip = true
    elsif command.downcase == "fps"
      $game_temp.fps == true ? ($game_temp.fps = false; $game_temp.fps_c.visible = false) : ($game_temp.fps = true; $game_temp.fps_c.visible = true)
    elsif command.downcase == "battle_gains"
      $game_temp.battle_gains == true ? $game_temp.battle_gains = false : $game_temp.battle_gains = true
    elsif command.downcase == "fullscreen"
      Keyboard.call(ZKey::Keys[:_alt], 0, 0, 0)
      Keyboard.call(ZKey::Keys[:_enter], 0, 0, 0)
      Keyboard.call(ZKey::Keys[:_alt], 0, 2, 0)
      Keyboard.call(ZKey::Keys[:_enter], 0, 2, 0)
    elsif command.downcase == "cai"
      $game_temp.cai == true ? $game_temp.cai = false : $game_temp.cai = true
    elsif ["invuln", "invulnerable", "invulnerability", "invincible", "invin"].include?(command.downcase)
      $game_temp.invuln == true ? $game_temp.invuln = false : $game_temp.invuln = true
    elsif command.to_i > 0
      events = $game_temp.disabled_events[$game_map.map_id]
      events.include?(command.to_i) ? events.delete(command.to_i) : events.push(command.to_i)
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Cosnole: check                                           NEW METHOD
  #  * the check method will run through the list of events on the map and
  #  * display which one are parallel processes, and which ones are autorun.
  #  * This can help greatly in figuring out why the player may be unable
  #  * to move. You can also specify 'all', and the command will check to
  #  * see if an event is ever a parallel process or autorun event.
  #--------------------------------------------------------------------------
  def check(type, *args)
    if SceneManager.last_scene_class == Scene_Map
      auto = []
      para = []
      if type == "" || type == nil || type.downcase == "current"
        $game_map.events.each { |ev|
          if ev[1].page.trigger == 3 # Autorun
            auto.push(ev[0])
          elsif ev[1].page.trigger == 4 # Parallel process
            para.push(ev[0])
          end
        }
        if auto != []
          @messages.unshift("Event#{ auto.size > 1 ? "s" : ""} #{auto.join(", ")} #{ auto.size > 1 ? "are" : "is an"} autorun event#{ auto.size > 1 ? "s" : ""}!")
        end
        if para != []
          @messages.unshift("Event#{ para.size > 1 ? "s" : ""} #{para.join(", ")} #{ para.size > 1 ? "are" : "is a"} parallel process#{ para.size > 1 ? "es" : ""}.")
        end
        if auto == [] && para == []
          @messages.unshift("No event is currently a parallel process, nor an autorun event.")
        end
      elsif type.downcase == "all"
        $game_map.events.each{ |ev|
          ev[1].event.pages.each { |page|
            if page.trigger == 3 && auto.include?(ev[0]) == false
              auto.push(ev[0])
            elsif page.trigger == 4 && para.include?(ev[0]) == false
              para.push(ev[0])
            end
          }
        }
        if auto != []
          @messages.unshift("Event#{ auto.size > 1 ? "s" : ""} #{auto.join(", ")} #{ auto.size > 1 ? "contain" : "contains an at least one"} autorun event#{ auto.size > 1 ? "s" : ""}!")
        end
        if para != []
          @messages.unshift("Event#{ para.size > 1 ? "s" : ""} #{para.join(", ")} #{ para.size > 1 ? "contain" : "contains at least one"} parallel process#{ para.size > 1 ? "es" : ""}.")
        end
        if auto == [] && para == []
          @messages.unshift("This map contains no parallel processes, nor autorun events.")
        end
      end
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: kill                                            NEW METHOD
  #  * This command will allow the player to kill off enemies during battle.
  #  * if battle_gains is toggled on, rewards from the killed enemies will
  #  * still be granted, regardless that it was not fair.
  #--------------------------------------------------------------------------
  def kill(selection, *args)
    if SceneManager.last_scene_class == Scene_Battle
      if selection.downcase == "all"
        $game_troop.members.reject! { |enemy|
          $game_temp.removed_enemies.push(enemy)
          true
        }
      elsif selection.to_i > 0
        $game_troop.members.reject!{ |enemy|
          if $game_troop.members.index(enemy) == selection.to_i - 1
            $game_temp.removed_enemies.push(enemy)
            true
          else
            false
          end
        }
      else
        @messages.unshift("Invalid enemy ID.")
      end
    else
      @messages.unshift("You are not in battle.")
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_console: transfer                                        NEW METHOD
  #  * Transfer allows the player to change the map that they are currently
  #  * on.
  #--------------------------------------------------------------------------
  def transfer(id, x, y, *args)
    $game_player.reserve_transfer(id.to_i, x.to_i, y.to_i, $game_player.direction)
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: moveto                                          NEW METHOD
  #  * Moveto allows the player to change where on the current map they are.
  #--------------------------------------------------------------------------
  def moveto(x, y, *args)
    $game_player.moveto(x.to_i, y.to_i)
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: cme                                             NEW METHOD
  #  * cme allows the game developer to run a common event.
  #--------------------------------------------------------------------------
  def cme(id, *args)
    $game_temp.reserve_common_event(id.to_i)
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: level                                           NEW METHOD
  #  * The level command allows the player to modify their character's
  #  * levels.
  #--------------------------------------------------------------------------
  def level(id, amount, *args)
    if amount > 0
      amount.times { $game_actors[id].level_up }
    else
      (amount.abs).times { $game_actors[id].level_down }
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: switch                                          NEW METHOD
  #  * The switch command allows a developer to modify the value of a game
  #  * switch through the console. It may only be used during a playtest.
  #--------------------------------------------------------------------------
  def switch(id, value, *args)
    if value.downcase == "on" || value.downcase == "true"
      $game_switches[id.abs.to_i] = true
    elsif value.downcase == "off" || value.downcase == "false"
      $game_switches[id.abs.to_i] = false
    end
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: variable                                        NEW METHOD
  #  * The variable command allows a developer to modify the value of a game
  #  * variable through the console. It may only be used during a playtest.
  #--------------------------------------------------------------------------
  def variable(id, value, *args)
    if id.to_i != 0
      $game_variables[id.abs.to_i] += value.to_i
    end
  end

  #--------------------------------------------------------------------------
  # Scene_Console: _restart                                        NEW METHOD
  #  * _restart will reset the entire game back to the title screen.
  #--------------------------------------------------------------------------
  def _restart(*args)
    Keyboard.call(ZKey::Keys[:_f12], 0, 0, 0)
    Keyboard.call(ZKey::Keys[:_f12], 0, 2, 0)
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: restart                                         NEW METHOD
  #  * Restart will reset the current scene
  #--------------------------------------------------------------------------
  def restart(*args)
    SceneManager.scene = SceneManager.scene.class.new
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: exit                                            NEW METHOD
  #  * Exit will forcibly quit the game.
  #--------------------------------------------------------------------------
  def exit(*args)
    SceneManager.scene = nil
  end
  
  #--------------------------------------------------------------------------
  # Scene_Console: run                                             NEW METHOD
  #  * Run will load a runnable file and execute each instruction. Runnable
  #  * files are text files that have console commands stored in them for
  #  * quick use of long or difficult to type tasks.
  #
  # code 1 is an unknown command
  # code 2 is invalid argument count
  # code 3 is a code error with the actual command (the Ruby code)
  #--------------------------------------------------------------------------
  def run(script, *args)
    ext = Zale::Console::Runnable_Extension
    script = "#{script}#{script.end_with?(".#{ext}") ? "" : ".run"}"
    begin
      if script.start_with?("internal:")
        script = script[9, script.size]
        runnable = load_data(script)
      elsif FileTest.exist?(script)
        runnable = File.open(script, "r+"){|f| f.read }
      elsif load_data(script)
        runnable = load_data(script)
      end
      runnable == nil ? (raise Errno::ENOENT) : nil
    rescue Errno::ENOENT => e
      @messages.unshift("The file \'#{script}\' could not be found, or encountered an error when being read. Please be sure that the filename is spelled correctly, and it is located in the correct folder.")
      return
    end
    header = runnable.scan(/^.*$/)[0]
    header[/key="(.*)"/]; key = $1
    header[/secure=(true|false)/]; secure = $1
    begin
      if (secure || Zale::Console::Restrict_Runnable_Access) && !$TEST || Zale::Console::Require_Runnable_Key && key != Zale::Console::Runnable_Key 
        raise Errno::EACCES
      end
    rescue Errno::EACCES => e
      @messages.unshift("There was a security error while trying to run #{script}. Either the access key was incorrect, you don't have sufficient privileges, or both.")
      return
    end
    content = runnable.scan(/^.*$/)
    content.delete_at(0)
    content.each{ |str|
      str.split(";").each_with_index{ |txt, index|
        if (code = process_command(txt.clone) < 0)
          @messages.unshift("An error in the script was encountered at line #{index + 2}. (Error Code #{-code})")
          return
        end
      }
    }
    @messages.unshift("Runnable script complete.")
  end
end

class Game_Map
  #--------------------------------------------------------------------------
  # Game_Map: update_interpreter                               ALIASED METHOD
  #  * This will check to see if a specific event, or all events, should be
  #  * disabled. If it is, then it will unlock the event and shutdown its
  #  * interpreter.
  #--------------------------------------------------------------------------
  alias zale_console_updateinter_b843mvie85 update_interpreter
  def update_interpreter
    if $game_temp.ai == false || $game_temp.disabled_events[@map_id].include?(@interpreter.event_id) == true
      if @interpreter.event_id > 0
        unlock_event(@interpreter.event_id)
        @interpreter.clear
      end
    elsif $game_temp.ai == true
      zale_console_updateinter_b843mvie85
    end
  end
end

class Game_Event < Game_Character
  attr_reader :page, :event
  #--------------------------------------------------------------------------
  # Game_Event: lock                                           ALIASED METHOD
  #  * If this event or all events should be disabled, this will do nothing,
  #  * otherwise it will turn the event toward the player until the event
  #  * finishes running, if they pressed the action button.
  #--------------------------------------------------------------------------
  alias zale_console_evlock_4yfu39dh7j lock
  def lock
    if !$game_temp.ai || $game_temp.disabled_events[@map_id].include?(@id)
      return
    elsif $game_temp.ai
      zale_console_evlock_4yfu39dh7j
    end
  end
  
  #--------------------------------------------------------------------------
  # Game_Event: update                                         ALIASED METHOD
  #  * If the event is disabled, it will not update the event. Otherwise,
  #  * the event is updated like normal.
  #--------------------------------------------------------------------------
  alias zale_console_evupdate_gu582kdd1a update
  def update
    if !$game_temp.disabled_events[@map_id].include?(@id) && $game_temp.ai
      zale_console_evupdate_gu582kdd1a
    end
  end
end

class Sprite_Character < Sprite_Base
  #--------------------------------------------------------------------------
  # Sprite_Character: initialize                               ALIASED METHOD
  #  * This method creates a new sprite for events and characters. The alias
  #  * adds some new variables for use with event ids.
  #--------------------------------------------------------------------------
  alias zale_console_charsprite_init_dut95mckap initialize
  def initialize(viewport, char = nil)
    @drawn     = false
    @id_sprite = Sprite.new
    @id_sprite.bitmap = Bitmap.new(Font.default_size * 5, Font.default_size)
    @id_sprite.visible = false
    zale_console_charsprite_init_dut95mckap(viewport, char)
  end
  
  #--------------------------------------------------------------------------
  # Sprite_Character: update_bitmap                            ALIASED METHOD
  #  * update_bitmap will update the location and visibility of event IDS, as
  #  * well as the actual event like it would normally.
  #--------------------------------------------------------------------------
  alias zale_console_charsprite_chars_fu592kgirq0 update_bitmap
  def update_bitmap
    zale_console_charsprite_chars_fu592kgirq0
    @id_sprite.bitmap.font.color = Color.new(255, 255, 0)
    @id_sprite.x = @character.real_x * 32 - $game_map.display_x * 32
    @id_sprite.y = @character.real_y * 32 - $game_map.display_y * 32
    if $game_temp.hover_ids == true && @character.class == Game_Event && @drawn == false
      @id_sprite.bitmap.clear
      @id_sprite.bitmap.draw_text(0, 0, Font.default_size * 5 + 4, Font.default_size, @character.id.to_s)
      @drawn = true
      @id_sprite.visible = true
    else
      if @id_sprite.visible == true && $game_temp.hover_ids == false && SceneManager.scene_is?(Scene_Map) == true
        @id_sprite.visible = false
        @drawn = false
      end
    end # Drawn indexes correct?
  end # Method
end # Class

class Game_Character < Game_CharacterBase
  #--------------------------------------------------------------------------
  # Game_Character: move_speed= & move_speed                      NEW METHODS
  #  * These methods are used to control the speed of the player's character.
  #  * attr_accessor creates both move_speed= and move_speed automatically.
  #--------------------------------------------------------------------------
  attr_accessor :move_speed
end

class Game_Player < Game_Character
  #--------------------------------------------------------------------------
  # Game_Player: encounter                                     ALIASED METHOD
  #  * This alias allows the player to disable random encounters.
  #--------------------------------------------------------------------------
  alias zale_console_encounter_fu29cjqodk encounter
  def encounter
    if $game_temp.cai == false
      make_encounter_count
      return false
    end
    zale_console_encounter_fu29cjqodk
  end

  #--------------------------------------------------------------------------
  # Game_Player: debug_through?                                ALIASED METHOD
  #  * This adds a check to see if the noclip property is set. If it is,
  #  * always allows that player to move.
  #--------------------------------------------------------------------------
  alias zale_console_debugthr_8ucmwyfht1 debug_through?
  def debug_through?
    zale_console_debugthr_8ucmwyfht1 || $game_temp.noclip == true
  end
end

class Game_Troop
  #--------------------------------------------------------------------------
  # Game_Troop: gold_total                                     ALIASED METHOD
  #  * If battle_gains is set to true, the player will be given the gold that
  #  * enemies removed by the console would have given them.
  #--------------------------------------------------------------------------
  alias zale_console_gold_61523fuqzd gold_total
  def gold_total
    if $game_temp.battle_gains == true
      zale_console_gold_61523fuqzd + ($game_temp.removed_enemies.inject(0) { |res, enemy| res += enemy.gold } * gold_rate)
    else
      zale_console_gold_61523fuqzd
    end
  end
  
  #--------------------------------------------------------------------------
  # Game_Troop: make_drop_items                                ALIASED METHOD
  #  * If battle_gains is set to true, the player will be given the items 
  #  * that enemies removed by the console would have given them.
  #--------------------------------------------------------------------------
  alias zale_console_items_d94hgkapwq make_drop_items
  def make_drop_items
    if $game_temp.battle_gains == true
      zale_console_items_d94hgkapwq + $game_temp.removed_enemies.inject([]) { |res, enemy| res += enemy.make_drop_items }
    else
      zale_console_items_d94hgkapwq
    end
  end
  
  #--------------------------------------------------------------------------
  # Game_Troop: exp_total                                      ALIASED METHOD
  #  * If battle_gains is set to true, the player will be given the exp that
  #  * enemies removed by the console would have given them. This method
  #  * also clears the removed enemies list because it is the last one called
  #  * by the battle manager. Erasing it here prevents additional aliasing
  #  * and potential bugs.
  #--------------------------------------------------------------------------
  alias zale_console_exp_cawqitucv8 exp_total
  def exp_total
    if $game_temp.battle_gains == true
      enemies = $game_temp.removed_enemies
      $game_temp.removed_enemies.clear
      zale_console_exp_cawqitucv8 + enemies.inject(0) { |res, enemy| res += enemy.exp }
    else
      zale_console_exp_cawqitucv8
    end
  end
end

class Game_Temp
  #--------------------------------------------------------------------------
  # Game_Temp                                                     NEW METHODS
  #  * All the attr_accessors below are changed by the console to control
  #  * certain parts of the game. Most of them are toggled through the
  #  * toggle command, while others (like removed_enemies) are tied to
  #  * different commands.
  #--------------------------------------------------------------------------
  attr_accessor :fps, :ai, :disabled_events, :hover_ids, :pass_in, :noclip
  attr_accessor :fps_c, :removed_enemies, :battle_gains, :cai, :frame_count
  attr_accessor :gfc, :invuln
  
  #--------------------------------------------------------------------------
  # Game_Temp: initialize                                      ALIASED METHOD
  #  * Initialize sets all the default values for the class, so here we set
  #  * all of our default values.
  #--------------------------------------------------------------------------
  alias zale_dsp_gtemp_init_cy67abghej initialize
  def initialize
    zale_dsp_gtemp_init_cy67abghej
    @fps             = false  # Show a somewhat FPS counter on the screen.
    @ai              = true   # Run events(AIs)?
    # These events are disabled and will not run until they are taken out of the list.
    @disabled_events = Hash.new {|hash, key| hash[key] = [] }
    @hover_ids       = false  # Have an event's ID hover over it on the map?
    @no_clip         = false  # Can the player walk through anything freely?
    @battle_gains    = false  # Gain items, gold, and exp if enemies are removed by console?
    @cai             = true
    @pass_in         = false  # Used by the console for authorization
    @fps_c           = Sprite.new # The sprite that will display how long it takes to draw frames.
    @fps_c.bitmap = Bitmap.new(Font.default_size * 10, Font.default_size)
    @fps_c.y = 1
    @fps_c.x = 1
    @fps_c.z = 999999
    @fps_c.visible = false
    @removed_enemies = []     # An array of enemies removed by console.
    @invuln = false
  end
  
  #--------------------------------------------------------------------------
  # Game_Temp: refresh_fps                                         NEW METHOD
  #  * Refresh_fps handles the actual drawing of the FPS to the game screen.
  #--------------------------------------------------------------------------
  def refresh_fps(fps)
    if @fps
      @fps_c.bitmap.clear
      if fps > Zale::Console::Low_Framerate
        @fps_c.bitmap.font.color = Color.new(255, 255, 0)
      else
        @fps_c.bitmap.font.color = Color.new(255, 0, 0)
      end
      @fps_c.bitmap.draw_text(@fps_c.bitmap.rect, "FPS: #{fps}")
    end
  end
end
